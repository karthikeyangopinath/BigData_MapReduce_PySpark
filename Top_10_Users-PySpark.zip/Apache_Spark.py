from pyspark import SparkContext
from operator import add
import os

curr_dir=os.getcwd();
text_file_path='file://'+curr_dir+'/u.user'
sc = SparkContext( 'local', 'pyspark')

def age_group(age):
	if age < 10 :
		return '0-10' 
	elif age < 20:
		return '10-20'
	elif age < 30:
		return '20-30'
	elif age < 40:
		return '30-40'
	elif age < 50:
		return '40-50'
	elif age < 60:
		return '50-60'
	elif age < 70:
		return '60-70'
	elif age < 80:
		return '70-80' 
	else:
		return '80+'

def parse_with_age_group(data):
	userid,age,gender,occupation,zip = data.split("|")
	return (age_group(int(age)),occupation)

def occupation_map(iterator):	
	yield [(x[1],1) for x in iterator]


fs=sc.textFile(text_file_path)
fs1=fs.map(parse_with_age_group)
fs2=fs1.filter(lambda x: x[0] in ['40-50','50-60'])
fs3=fs2.partitionBy(2,lambda x:x =='40-50')
fs4=fs3.mapPartitions(occupation_map).collect()
g1=sc.parallelize(sc.parallelize(fs4[0]).reduceByKey(add).map(lambda x: (x[1],x[0])).sortByKey(False).top(10)).map(lambda x: x[1])
g2=sc.parallelize(sc.parallelize(fs4[1]).reduceByKey(add).map(lambda x: (x[1],x[0])).sortByKey(False).top(10)).map(lambda x: x[1])
output = g1.intersection(g2).collect()
print(output)
